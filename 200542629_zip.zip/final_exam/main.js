let header = document.querySelector('#header');
let footer = document.querySelector('#footer');

fetch('./header.html')
    .then(response => response.text())
    .then(html => header.innerHTML = html);

fetch('./footer.html')
    .then(response => response.text())
    .then(html => footer.innerHTML = html);

    
